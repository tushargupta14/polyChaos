The documentation for Matlab 2012b or newer can be accessed via
Help->Supplemental Software
For older versions of Matlab it can be accessed via Matlab start menu.