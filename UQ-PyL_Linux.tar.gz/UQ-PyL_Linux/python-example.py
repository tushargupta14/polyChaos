# Optional - turn off bytecode (.pyc files)
import sys
sys.dont_write_bytecode = True

from UQ.DoE import monte_carlo, normal, sobol, lhs, box_behnken, central_composite, fast_sampler,\
ff2n, finite_diff, frac_fact, full_fact, morris_oat, plackett_burman, saltelli, symmetric_LH
from UQ.analyze import *
from UQ.RSmodel import gp, SVR, DT, kNN, BayesianRidge,\
OrdinaryLeastSquares, LAR, Lasso, Ridge, SGD
from UQ.optimization import SCE, ASMO
from UQ.test_functions import Sobol_G
from UQ.util import scale_samples_general, read_param_file, discrepancy
import numpy as np
import random as rd

# Example: Run Sobol, Morris, or FAST on a test function (Sobol G Function)
# The parameters shown for each method are also the default values if omitted

# Set random seed (does not affect quasi-random Sobol sampling)
seed = 1
np.random.seed(seed)
rd.seed(seed)

# Read the parameter range file and generate samples
param_file = './UQ/test_functions/params/WRF.txt'
pf = read_param_file(param_file)

# Generate samples (choose method here)
# param_values = monte_carlo.sample(500, pf['num_vars'])
# param_values = normal.sample(100, pf['num_vars'])
# param_values = sobol.sample(17, pf['num_vars'])
# param_values = halton.sample(100, pf['num_vars'])
# param_values = saltelli.sample(257, pf['num_vars'], calc_second_order = True)
param_values = morris_oat.sample(10, pf['num_vars'], num_levels = 4, grid_jump = 2)
# param_values = fast_sampler.sample(100, pf['num_vars'])
# param_values = symmetric_LH.sample(20, pf['num_vars'])
# param_values = lhs.sample(500, pf['num_vars'], criterion='center')
# param_values = full_fact.sample([15,3,6])
# param_values = ff2n.sample(5)
# param_values = frac_fact.sample("a b ab")
# param_values = plackett_burman.sample(pf['num_vars'])
# param_values = box_behnken.sample(3)
# param_values = central_composite.sample(3)
# param_values = finite_diff.sample(1000, param_file, delta=0.001)
# res = discrepancy.evaluate(param_values)
# print res

# Samples are given in range [a, b] by default. Rescale them to your parameter bounds.
scale_samples_general(param_values, pf['bounds'])

# For Method of Morris, save the parameter values in a file (they are needed in the analysis)
# FAST and Sobol do not require this step, unless you want to save samples to input into an external model
np.savetxt('Input_WRF.txt', param_values, delimiter=' ')

# Run the "model" and save the output in a text file
# This will happen offline for external models
# Y = Sobol_G.evaluate(param_values)
# np.savetxt("SGOutput.txt", Y, delimiter=' ')

# Perform the sensitivity analysis/uncertainty analysis using the model output
# Specify which column of the output file to analyze (zero-indexed)
# moments.analyze('SGOutput.txt', column=0)
# confidence.analyze('SGOutput.txt', column=0)
# correlations.analyze(param_file, 'SGInput.txt', 'SGOutput.txt')
# hypothesis.analyze(param_file, 'SGInput.txt', 'SGOutput.txt')
# sobol_analyze.analyze(param_file, 'SGOutput.txt', column = 0, calc_second_order = True)
# morris.analyze(param_file, 'SGInput.txt', 'SGOutput.txt', column = 0)
# extended_fast.analyze(param_file, 'SGOutput.txt', column = 0)
# dgsm.analyze(param_file, 'SGInput.txt', 'SGOutput.txt', column=0)
# delta.analyze(param_file, 'SGInput.txt', 'SGOutput.txt', column=0)
# sobol_svm.analyze(param_file, 'SGInput.txt', 'SGOutput.txt', N_rbf=10000, n_folds=10, column=0)
              
# Perform regression analysis using the model output
# Specify which column of the output file to analyze (zero-indexed)
# model = gp.regression('SGInput.txt', 'SGOutput.txt', column = 0, cv = False)
# model = SVR.regression('SGInput.txt', 'SGOutput.txt', column = 0, cv = True)
# model = DT.regression('SGInput.txt', 'SGOutput.txt', column = 0, cv = True)
# model = kNN.regression('SGInput.txt', 'SGOutput.txt', weights = 'uniform', column = 0, cv = True)
# model = kNN.regression('SGInput.txt', 'SGOutput.txt', weights = 'distance', column = 0, cv = True)
# model = BayesianRidge.regression('SGInput.txt', 'SGOutput.txt', column = 0, cv = True)
# model = OrdinaryLeastSquares.regression('SGInput.txt', 'SGOutput.txt', column = 0, cv = True)
# model = Lasso.regression('SGInput.txt', 'SGOutput.txt', column = 0, cv = True)
# model = LAR.regression('SGInput.txt', 'SGOutput.txt', column = 0, cv = True)
# model = Ridge.regression('SGInput.txt', 'SGOutput.txt', column = 0, cv = True)
# model = SGD.regression('SGInput.txt', 'SGOutput.txt', column = 0, cv = True)

# Perform optimization analysis
# bl=np.empty(0)
# bu=np.empty(0)
# for i, b in enumerate(pf['bounds']):
    # bl = np.append(bl, b[0])
    # bu = np.append(bu, b[1])

# dir = './UQ/test_functions/'
# shutil.copy(dir+'SAC.py', dir+'functn.py')

# SCE.sceua(bl, bu, pf, ngs=2)
# ASMO.optimization(bl, bu, pf, max_sample = 100)
# DDS.optimization(bl, bu, pf, max_sample = 20)
# PSO.optimization(bl, bu, pf)