# Optional - turn off bytecode (.pyc files)
import sys
sys.dont_write_bytecode = True
import shutil
from UQ.optimization import SCE, ASMO, DDS, PSO
from UQ.util import scale_samples_general, read_param_file, discrepancy
import numpy as np
import random as rd

# Read the parameter range file
param_file = './UQ/test_functions/params/Sobol_G.txt'

bl=np.empty(0)
bu=np.empty(0)
pf = read_param_file(param_file)
for i, b in enumerate(pf['bounds']):
    bl = np.append(bl, b[0])
    bu = np.append(bu, b[1])

dir = './UQ/test_functions/'
shutil.copy(dir+'Sobol_G.py', dir+'functn.py')

# Run SCE-UA optimization algorithm
# SCE.sceua(bl, bu, pf, ngs=2)
ASMO.optimization(bl, bu, pf, max_sample = 100)
# DDS.optimization(bl, bu, pf, max_sample = 20)
# PSO.optimization(bl, bu, pf)
# GA.optimization(bl, bu, pf)
# SA.optimization(bl, bu, pf)
# MCMC.optimization(bl, bu, pf)