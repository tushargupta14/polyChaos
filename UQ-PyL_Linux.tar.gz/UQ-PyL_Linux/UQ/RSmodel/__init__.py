__all__ = ["gp", "SVR", "DT", "RF", "MARS", "kNN", "Lars", "ElasticNet", \
"BayesianRidge", "kNN", "LAR", "Lasso", "OrdinaryLeastSquares", "Ridge", "SGD"]