# Optional - turn off bytecode (.pyc files)
import sys
sys.dont_write_bytecode = True

from UQ.DoE import monte_carlo
from UQ.RSmodel import SVR
from UQ.test_functions import Sobol_G
from UQ.util import scale_samples_general, read_param_file, discrepancy
import numpy as np
import random as rd

# Set random seed (does not affect quasi-random Sobol sampling)
seed = 1
np.random.seed(seed)
rd.seed(seed)

# Read the parameter range file and generate samples
param_file = './UQ/test_functions/params/Sobol_G.txt'
pf = read_param_file(param_file)

# Generate samples (choose method here)
param_values = monte_carlo.sample(500, pf['num_vars'])

# Samples are given in range [0, 1] by default. Rescale them to your parameter bounds.
scale_samples_general(param_values, pf['bounds'])
np.savetxt('Input_Sobol\'.txt', param_values, delimiter=' ')

# Run the "model" and save the output in a text file
# This will happen offline for external models
Y = Sobol_G.evaluate(param_values)
np.savetxt("Output_Sobol\'.txt", Y, delimiter=' ')

# Perform regression analysis using the model output
# Specify which column of the output file to analyze (zero-indexed)
model = SVR.regression('Input_Sobol\'.txt', 'Output_Sobol\'.txt', column = 0, cv = True)