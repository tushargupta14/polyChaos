Please move all the files to the upper folder, then you can run the example files with no error.

cp * ../
cd ..
python Sobol_G_DoE.py
python Sobol_G_UA.py
python Sobol_G_SA.py
python Sobol_G_Surrogate.py
python Sobol_G_Optimization.py